


import javax.swing.JFrame; //utilized Java swing for this project

//main method
public class CalculatorMain {
	public static void main(String[] args) {
		//calculator main frame
		Frame myCalc = new Frame();
		myCalc.setTitle("Calculator");//title of the Programmer Calculator
		
		myCalc.setBounds(100, 100, 375, 595);//bounds for the size of the window
		myCalc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//the window will close over here
		myCalc.setVisible(true);			
	}
	
}