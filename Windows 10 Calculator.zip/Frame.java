
//imports
import java.awt.Color; 
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
//contains objects of all the other object classes
import javax.swing.JLabel;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

//Main frame of the java program

//variables
public class Frame extends JFrame {
	private TextfieldPanel InputPanel;
	private ConversionPanel BasePanel;
	private ButtonsPanel ButtonPanel;
	private JToggleButton QWORD;
	private JButton And, Not, Or, Xor, Rsh, Lsh;
	private JLabel Menu, Title;
	
	public Frame () {
		//layout of the frame
		setLayout(null);

		//where the user enters the text
		InputPanel = new TextfieldPanel();
		//set the default font, background and foreground
		InputPanel.setFont(new Font("Lucida Grande", Font.PLAIN, 13));			
		InputPanel.setBackground(new Color(238,238,238));
		InputPanel.setForeground(Color.BLACK);
		InputPanel.setBounds(6, 55, 359, 65);
		add(InputPanel);
		
		Menu = new JLabel("   \u2630");
		//set font and bounds (size)
		Menu.setFont(new Font("Baskerville", Font.PLAIN, 20));
		Menu.setBounds(2, 6, 61, 37);
		add(Menu);
		
		//title on the top of the frame
		Title = new JLabel("PROGRAMMER");
		Title.setFont(new Font("Ajay Palankar", Font.BOLD, 16));
		Title.setBounds(64, 14, 263, 40);
		add(Title);
		
		//basePanel - panel that includes hex, bin, decimal and octal buttons
		BasePanel = new ConversionPanel();
		BasePanel.setBounds(6, 153, 63, 140);
		BasePanel.setBorder(new EmptyBorder(0,0,0,0));
		add(BasePanel);
	
		//adds buttons to the calculator
		ButtonPanel = new ButtonsPanel();
		//set bounds as to where the buttons are placed on the frame
		ButtonPanel.setBounds(6, 336, 359, 231);
		add(ButtonPanel);	
		//buttons implemented for touch and feel
	    And = new JButton(" And");
		And.setBounds(306, 290, 57, 46);
		add(And);
		
		Not = new JButton(" Not");
		Not.setBounds(246, 290, 57, 46);
		add(Not);
		
		Xor = new JButton(" Xor");
		Xor.setBounds(186, 290, 57, 46);
		add(Xor);
		
		Or = new JButton(" Or");
		Or.setBounds(126, 290, 57, 46);
		add(Or);
		
		Rsh = new JButton(" Rsh");
		Rsh.setBounds(67, 290, 57, 46);
		add(Rsh);
		
		Lsh = new JButton(" Lsh");
		Lsh.setBounds(7,290, 57, 46);
		add(Lsh);
		
		//QWORD button implementation for touch and feel
		QWORD = new JToggleButton("QWORD");
		QWORD.setFont(new Font("Ajay Palankar", Font.PLAIN, 14));
		QWORD.setBounds(142, 245, 100, 40);
		add(QWORD);			
	}	
}
