

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
public class ConversionPanel extends JPanel implements ActionListener {
	
	private static JRadioButton hexadecimal; 
	private static JRadioButton decimal;
	private static JRadioButton octal;
	private static JRadioButton binary;
	private ButtonGroup baseButtonGroup;
//JRadioButton will be needed for the options above, as in a programmer calculator,
//the user will need to differentiate between hexadecimal, decimal, octal, and binary
//CONSTRUCTOR	
	public ConversionPanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBorder(BorderFactory.createTitledBorder(""));
		
		hexadecimal = new JRadioButton("Hex");
		decimal = new JRadioButton("Dec");
		octal = new JRadioButton("Oct");
		binary = new JRadioButton("Bin");
		
		baseButtonGroup = new ButtonGroup();
	
		//Adding radio buttons to group
		baseButtonGroup.add(hexadecimal);
		baseButtonGroup.add(decimal);
		decimal.setSelected(true);
		baseButtonGroup.add(octal);
		baseButtonGroup.add(binary);
		
		//Adding to panel
		add(hexadecimal);
		add(decimal);
		add(octal);
		add(binary);
		
		//Adding ActionListener
		hexadecimal.addActionListener(this);
		decimal.addActionListener(this);
		octal.addActionListener(this);
		binary.addActionListener(this);
	}
	
	//helper methods to get the buttons the user is interacting with
	public static JRadioButton getHexRadButton() { return hexadecimal; }
	public static JRadioButton getDecRadButton() { return decimal; }
	public static JRadioButton getOctRadButton() { return octal; }
	public static JRadioButton getBinRadButton() { return binary; }
	
	//ActionListener
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == hexadecimal) {//when hex is chosen, the operations below will take place
			
			int number = TextfieldPanel.getCurrentNumberInDecimal();
			
			if(number != 0) {
				//convert number to hexadecimal
				TextfieldPanel.getTextField().setText(ButtonsPanel.convertNumberTo(number));
			}

			//set ABCDE to true
			ButtonsPanel.getButton(6).setEnabled(true);
			ButtonsPanel.getButton(7).setEnabled(true);
			ButtonsPanel.getButton(12).setEnabled(true);
			ButtonsPanel.getButton(13).setEnabled(true);
			ButtonsPanel.getButton(18).setEnabled(true);
			ButtonsPanel.getButton(19).setEnabled(true);
			
			//set all numbers to true
			ButtonsPanel.getButton(8).setEnabled(true);
			ButtonsPanel.getButton(9).setEnabled(true);
			ButtonsPanel.getButton(10).setEnabled(true);
			
			ButtonsPanel.getButton(14).setEnabled(true);
			ButtonsPanel.getButton(15).setEnabled(true);
			ButtonsPanel.getButton(16).setEnabled(true);
			
			ButtonsPanel.getButton(20).setEnabled(true);
			ButtonsPanel.getButton(21).setEnabled(true);
			ButtonsPanel.getButton(22).setEnabled(true);
			ButtonsPanel.getButton(27).setEnabled(true);
			
		}
		if(e.getSource() == decimal) { //when dec is chosen, the operations below will take place
			
			int number = TextfieldPanel.getCurrentNumberInDecimal();
			
			if(number != 0) {
				//convert number to decimal
				TextfieldPanel.getTextField().setText(ButtonsPanel.convertNumberTo(number));
			}
				//set A, B, C, D, E, F to false
				ButtonsPanel.getButton(6).setEnabled(false);
				ButtonsPanel.getButton(7).setEnabled(false);
				ButtonsPanel.getButton(12).setEnabled(false);
				ButtonsPanel.getButton(13).setEnabled(false);
				ButtonsPanel.getButton(18).setEnabled(false);
				ButtonsPanel.getButton(19).setEnabled(false);
			
			//set all numbers to true
				ButtonsPanel.getButton(8).setEnabled(true);
				ButtonsPanel.getButton(9).setEnabled(true);
				ButtonsPanel.getButton(10).setEnabled(true);
				
				ButtonsPanel.getButton(14).setEnabled(true);
				ButtonsPanel.getButton(15).setEnabled(true);
				ButtonsPanel.getButton(16).setEnabled(true);
				
				ButtonsPanel.getButton(20).setEnabled(true);
				ButtonsPanel.getButton(21).setEnabled(true);
				ButtonsPanel.getButton(22).setEnabled(true);
				ButtonsPanel.getButton(27).setEnabled(true);
			
		}
		if(e.getSource() == octal) { //when octal is chosen, the following operations below will take place
		
			int number = TextfieldPanel.getCurrentNumberInDecimal();
			
			if(number != 0) {
				//convert number to octal
				TextfieldPanel.getTextField().setText(ButtonsPanel.convertNumberTo(number));
			}
				//set A, B, C, D, E, F to false
				ButtonsPanel.getButton(6).setEnabled(false);
				ButtonsPanel.getButton(7).setEnabled(false);
				ButtonsPanel.getButton(12).setEnabled(false);
				ButtonsPanel.getButton(13).setEnabled(false);
				ButtonsPanel.getButton(18).setEnabled(false);
				ButtonsPanel.getButton(19).setEnabled(false);
				
			//set 8 and 9 to false
			ButtonsPanel.getButton(9).setEnabled(false);
			ButtonsPanel.getButton(10).setEnabled(false);
			//set all other numbers to true
			ButtonsPanel.getButton(8).setEnabled(true);
			
			ButtonsPanel.getButton(14).setEnabled(true);
			ButtonsPanel.getButton(15).setEnabled(true);
			ButtonsPanel.getButton(16).setEnabled(true);
			
			ButtonsPanel.getButton(20).setEnabled(true);
			ButtonsPanel.getButton(21).setEnabled(true);
			ButtonsPanel.getButton(22).setEnabled(true);
			ButtonsPanel.getButton(27).setEnabled(true);
		
		}
		if(e.getSource() == binary) {//when binary is chosen, the following operations below will take place
			int number = TextfieldPanel.getCurrentNumberInDecimal();
			
			if(number != 0) {
				//convert number to binary
				TextfieldPanel.getTextField().setText(ButtonsPanel.convertNumberTo(number));
			}
			
			//set A, B, C, D, E, F to false
			ButtonsPanel.getButton(6).setEnabled(false);
			ButtonsPanel.getButton(7).setEnabled(false);
			ButtonsPanel.getButton(12).setEnabled(false);
			ButtonsPanel.getButton(13).setEnabled(false);
			ButtonsPanel.getButton(18).setEnabled(false);
			ButtonsPanel.getButton(19).setEnabled(false);
			
			//set all numbers to false
			ButtonsPanel.getButton(8).setEnabled(false);
			ButtonsPanel.getButton(9).setEnabled(false);
			ButtonsPanel.getButton(10).setEnabled(false);
			
			ButtonsPanel.getButton(14).setEnabled(false);
			ButtonsPanel.getButton(15).setEnabled(false);
			ButtonsPanel.getButton(16).setEnabled(false);
			
			ButtonsPanel.getButton(21).setEnabled(false);
			ButtonsPanel.getButton(22).setEnabled(false);
			//except 1 and 0
		}
	}
}


